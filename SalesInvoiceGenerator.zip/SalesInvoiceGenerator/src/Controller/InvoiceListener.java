/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Controller;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.text.ParseException;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.stream.Collectors;
import javax.swing.JFileChooser;
import javax.swing.JOptionPane;
import javax.swing.event.ListSelectionEvent;
import javax.swing.event.ListSelectionListener;
import Model.InvoiceHeader;
import Model.InvoiceHeadersTableModel;
import Model.InvoiceLine;
import Model.InvoiceLineTableModel;
import View.InvoiceFrame;

/**
 *
 * @author Abeer
 */
public class InvoiceListener implements ActionListener, ListSelectionListener {

    private InvoiceFrame invoiceFrame;

    public InvoiceListener(InvoiceFrame invoiceFrame) {
        this.invoiceFrame = invoiceFrame;
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        String actionCommand = e.getActionCommand();
        switch (actionCommand) {
            case "Create new invoice":
                createNewInvoice();
                break;

            case "Add new invoice":
                addNewInvoiceHeader();
                break;

            case "Cancel":
                CancelAddNewInvoice();
                break;

            case "Delete invoice":
                deleteInvoice();
                break;

            case "New line":
                createNewInvoiceLine();
                break;

            case "Add new line":
                addNewInvoiceLine();
                break;

            case "CancelAddingLine":
                CancelAddNewLine();
                break;

            case "Delete line":
                DeleteLine();
                break;

            case "Load Files": 
                loadFiles(null, null);
                break;

            case "Save Files":
                saveFiles();
                break;

        }

    }

    @Override
    public void valueChanged(ListSelectionEvent e) {

        //System.out.println("Action done here in table");
        int row = invoiceFrame.getInvoiceHeaderjTable().getSelectedRow();
        if (row > -1 && row < invoiceFrame.getInvoiceheaders().size()) {
            InvoiceHeader invoiceHeaderRow = invoiceFrame.getInvoiceheaders().get(row);
            invoiceFrame.getCustomerNamejLabel().setText(invoiceHeaderRow.getCustomerName());
            invoiceFrame.getInvoiceDatejLabel().setText(InvoiceFrame.simpleDateFormat.format(invoiceHeaderRow.getInvoiceDate()) + "");
            invoiceFrame.getInvoiceNumjLabel().setText(invoiceHeaderRow.getInvoiceNum() + "");
            invoiceFrame.getInvoiceTotaljLabel().setText(invoiceHeaderRow.getTotal() + "");

            ArrayList<InvoiceLine> lines = invoiceHeaderRow.getLines();
            invoiceFrame.getInvoiceLinesjTable().setModel(new InvoiceLineTableModel(lines));

        } else {
            invoiceFrame.getCustomerNamejLabel().setText("");
            invoiceFrame.getInvoiceDatejLabel().setText("");
            invoiceFrame.getInvoiceNumjLabel().setText("");
            invoiceFrame.getInvoiceTotaljLabel().setText("");
            invoiceFrame.getInvoiceLinesjTable().setModel(new InvoiceLineTableModel(new ArrayList<InvoiceLine>()));

        }
    }

    private void createNewInvoice() {

        invoiceFrame.getjNewInvoiceHeaderjDialog().pack();
        invoiceFrame.getjNewInvoiceHeaderjDialog().setVisible(true);

    }

    private void deleteInvoice() {
        int selectedHeaderToDelete = invoiceFrame.getInvoiceHeaderjTable().getSelectedRow();
        if (selectedHeaderToDelete != -1) {
            invoiceFrame.getInvoiceheaders().remove(selectedHeaderToDelete);
            ((InvoiceHeadersTableModel) invoiceFrame.getInvoiceHeaderjTable().getModel()).fireTableDataChanged();
        }
    }

    private void createNewInvoiceLine() {

        int selectedHeaderToAddFor = invoiceFrame.getInvoiceHeaderjTable().getSelectedRow();
        if (selectedHeaderToAddFor != -1) {
            invoiceFrame.getNewInvoiceLineDialog().pack();
            invoiceFrame.getNewInvoiceLineDialog().setVisible(true);
        }

    }

    private void DeleteLine() {
        int selectedLineToDelete = invoiceFrame.getInvoiceLinesjTable().getSelectedRow();
        if (selectedLineToDelete != -1) {
            int selectedHeaderRow = invoiceFrame.getInvoiceHeaderjTable().getSelectedRow();
            InvoiceLineTableModel invoiceLineTableModel = (InvoiceLineTableModel) invoiceFrame.getInvoiceLinesjTable().getModel();
            invoiceLineTableModel.getInvoiceLines().remove(selectedLineToDelete);
            invoiceLineTableModel.fireTableDataChanged();
            ((InvoiceHeadersTableModel) invoiceFrame.getInvoiceHeaderjTable().getModel()).fireTableDataChanged();
            invoiceFrame.getInvoiceHeaderjTable().setRowSelectionInterval(selectedHeaderRow, selectedHeaderRow);

        }

    }
    
    
//FILES
    public void loadFiles(String InvoiceHeaderPath, String linesPath) {
        File headerFile = null;
        File lineFile = null;

        if (InvoiceHeaderPath == null && linesPath == null) {
            // invoiceFrame.getInvoiceHeaderjTable().removeAll();
            //invoiceFrame.getInvoiceHeaderjTable().setModel(new DefaultTableModel()); 

            JFileChooser fc = new JFileChooser();
            int result = fc.showOpenDialog(invoiceFrame);
            if (result == JFileChooser.APPROVE_OPTION) {
                headerFile = fc.getSelectedFile();
                //System.out.println("headerFile : " + headerFile.getAbsolutePath().toString());
                result = fc.showOpenDialog(invoiceFrame);
                if (result == JFileChooser.APPROVE_OPTION) {
                    lineFile = fc.getSelectedFile();
                    //System.out.println("LineFile : " + lineFile.getAbsolutePath().toString());
                }
            }
        } else {

            headerFile = new File(InvoiceHeaderPath);
            //System.out.println("InvoiceHeaderPath" + InvoiceHeaderPath);
            lineFile = new File(linesPath);
        }

        if (headerFile != null && lineFile != null) {
            try {
                List<String> headerFileRows = Files.lines(Paths.get(headerFile.getAbsolutePath())).collect(Collectors.toList());
                List<String> linesFileRows = Files.lines(Paths.get(lineFile.getAbsolutePath())).collect(Collectors.toList());

                invoiceFrame.getInvoiceheaders().clear();
                for (String InvoiceHeadersFromFile : headerFileRows) {
                    String[] headerRowParts = InvoiceHeadersFromFile.split(",");
                    int invNum = Integer.parseInt(headerRowParts[0]);
                    Date invDate = invoiceFrame.simpleDateFormat.parse(headerRowParts[1]);
                    String invname = headerRowParts[2];
                    InvoiceHeader invoice = new InvoiceHeader(invNum, invDate, invname);
                    //note to me : Next line get an object from invoice header class then add an invoice header {invoice} to it. 
                    invoiceFrame.getInvoiceheaders().add(invoice);
                }

                for (String InvoiceLineFromFile : linesFileRows) {
                    String[] lineRowParts = InvoiceLineFromFile.split(",");
                    int headerNum = Integer.parseInt(lineRowParts[0]);
                    String itemName = lineRowParts[1];
                    double itemPrice = Double.parseDouble(lineRowParts[2]);
                    int itemCount = Integer.parseInt(lineRowParts[3]);
                    InvoiceHeader invoice = getInvoiceHeaderByHeaderNumber(headerNum);
                    InvoiceLine invoiceLine = new InvoiceLine(headerNum, itemName, itemPrice, itemCount, invoice);
                    invoice.getLines().add(invoiceLine);

                }
                //System.out.println("is working");
                invoiceFrame.getInvoiceHeaderjTable().setModel(new InvoiceHeadersTableModel(invoiceFrame.getInvoiceheaders()));

            } catch (Exception ex) {
                ex.printStackTrace();
            }

        }

    }
    
    //ENDFILES
    
    

    private InvoiceHeader getInvoiceHeaderByHeaderNumber(int headerNum) {
        for (InvoiceHeader invoiveHeaderRow : invoiceFrame.getInvoiceheaders()) {
            if (headerNum == invoiveHeaderRow.getInvoiceNum()) {
                return invoiveHeaderRow;
            }
        }

        return null;
    }

    private void saveFiles() {
        String headersData = "";
        String linesData = "";
        for (InvoiceHeader header : invoiceFrame.getInvoiceheaders()) {
            headersData += header.ExportedHeaderData() + "\n";
            for (InvoiceLine line : header.getLines()) {
                linesData += line.ExportedLineData() + "\n";
            }
        }
        JFileChooser fc = new JFileChooser();
        int result = fc.showOpenDialog(invoiceFrame);
        if (result == JFileChooser.APPROVE_OPTION) {
            File headerFile = fc.getSelectedFile();
            //System.out.println("headerFile : " + headerFile.getAbsolutePath().toString());
            result = fc.showOpenDialog(invoiceFrame);
            if (result == JFileChooser.APPROVE_OPTION) {
                File lineFile = fc.getSelectedFile();
                try {
                    FileWriter headerWriter = new FileWriter(headerFile);
                    headerWriter.write(headersData);
                    headerWriter.flush();
                    headerWriter.close();

                    FileWriter lineWriter = new FileWriter(lineFile);
                    lineWriter.write(linesData);
                    lineWriter.flush();
                    lineWriter.close();
                } catch (IOException ex) {
                    JOptionPane.showMessageDialog(invoiceFrame, "Error happened while exporting data", "Error", JOptionPane.ERROR_MESSAGE);
                }

            }
        }

    }

    private void addNewInvoiceHeader() {
        String customerNameOfNewInvoice = invoiceFrame.getDialogCustomerNamejText().getText();
        String invoiceDateOfNewInvoice = invoiceFrame.getDialogInvoiceDatejText().getText();
        invoiceFrame.getjNewInvoiceHeaderjDialog().setVisible(false);
        invoiceFrame.getjNewInvoiceHeaderjDialog().dispose();

        try {
            InvoiceHeader addInvoice = new InvoiceHeader(getNextInvoiceNum(), invoiceFrame.simpleDateFormat.parse(invoiceDateOfNewInvoice), customerNameOfNewInvoice);
            invoiceFrame.getInvoiceheaders().add(addInvoice);
            ((InvoiceHeadersTableModel) invoiceFrame.getInvoiceHeaderjTable().getModel()).fireTableDataChanged();

        } catch (ParseException ex) {
            JOptionPane.showMessageDialog(invoiceFrame, "Error in date format , make sure its format is dd-mm-yyyy", "Wrong data", 0);
        }

    }

    private int getNextInvoiceNum() {
        int num = -1;
        for (InvoiceHeader invHeader : invoiceFrame.getInvoiceheaders()) {
            if (invHeader.getInvoiceNum() > num) {
                num = invHeader.getInvoiceNum();
            }
        }

        return num + 1;
    }

    private void CancelAddNewInvoice() {
        invoiceFrame.getjNewInvoiceHeaderjDialog().setVisible(false);
        invoiceFrame.getjNewInvoiceHeaderjDialog().dispose();
    }

    private void CancelAddNewLine() {
        invoiceFrame.getNewInvoiceLineDialog().setVisible(false);
        invoiceFrame.getNewInvoiceLineDialog().dispose();
    }

    private void addNewInvoiceLine() {
        int selectedHeaderToAddFor = invoiceFrame.getInvoiceHeaderjTable().getSelectedRow();
        if (selectedHeaderToAddFor != -1) {
            InvoiceHeader selectedInvoiceHeader = invoiceFrame.getInvoiceheaders().get(selectedHeaderToAddFor);
            int headerNum = selectedInvoiceHeader.getInvoiceNum();
            String itemName = invoiceFrame.getDialogItemName().getText();
            double itemPrice = Double.parseDouble(invoiceFrame.getDialogItemPrice().getText());
            int itemCount = Integer.parseInt(invoiceFrame.getDialogItemCount().getText());
            invoiceFrame.getNewInvoiceLineDialog().setVisible(false);
            invoiceFrame.getNewInvoiceLineDialog().dispose();
            InvoiceLine newAddedLine = new InvoiceLine(headerNum, itemName, itemPrice, itemCount, selectedInvoiceHeader);
            selectedInvoiceHeader.getLines().add(newAddedLine);
            ((InvoiceLineTableModel) invoiceFrame.getInvoiceLinesjTable().getModel()).fireTableDataChanged();
            ((InvoiceHeadersTableModel) invoiceFrame.getInvoiceHeaderjTable().getModel()).fireTableDataChanged();
            invoiceFrame.getInvoiceHeaderjTable().setRowSelectionInterval(selectedHeaderToAddFor, selectedHeaderToAddFor);

        }
    }

}
