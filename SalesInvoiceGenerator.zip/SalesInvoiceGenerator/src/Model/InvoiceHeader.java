/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Model;


import java.util.Date;
import java.util.ArrayList;
import View.InvoiceFrame;

import java.util.ArrayList;
import javax.swing.table.AbstractTableModel;
import View.InvoiceFrame;
/**
 *
 * @author Abeer
 */
public class InvoiceHeader {

    private int invoiceNum;
    private Date invoiceDate;
    private String customerName;
    private ArrayList<InvoiceLine> lines;

    public InvoiceHeader(int invoiceNum, Date invoiceDate, String customerName) {
        this.invoiceNum = invoiceNum;
        this.invoiceDate = invoiceDate;
        this.customerName = customerName;
    }
    public String ExportedHeaderData()
    {
        return invoiceNum + "," + InvoiceFrame.simpleDateFormat.format(invoiceDate) + "," + customerName;
    }


    
    public int getInvoiceNum() {
        return invoiceNum;
    }

    public Date getInvoiceDate() {
        return invoiceDate;
    }

    public String getCustomerName() {
        return customerName;
    }

    public double getTotal() {
        double total = 0.0;
        for (InvoiceLine line : getLines()) {
            total += line.getLineTotal();
        }
        return total;
    }

    public ArrayList<InvoiceLine> getLines() {
        if (lines == null) {
            lines = new ArrayList<>();
        }

        return lines;
    }
    
    

}

