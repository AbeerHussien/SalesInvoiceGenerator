/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Model;

/**
 *
 * @author Abeer
 */
public class InvoiceLine {

    private int invoiceNumber;
    private String itemName;
    private double itemPrice;
    private int itemCount;
    InvoiceHeader invoiceHeader;

    public InvoiceLine(int invoiceNumber,String itemName, double itemPrice, int itemCount, InvoiceHeader invoiceHeader) {
        
        this.invoiceNumber=invoiceNumber;
        this.itemName = itemName;
        this.itemPrice = itemPrice;
        this.itemCount = itemCount;
        this.invoiceHeader = invoiceHeader;
    }
    
    public String ExportedLineData()
    {
        return invoiceNumber +","+ itemName + "," + itemPrice + "," + itemCount;
    }

    //getter methods
    public String getItemName() {
        return itemName;
    }

    public double getItemPrice() {
        return itemPrice;
    }

    public int getItemCount() {
        return itemCount;
    }

    public double getLineTotal() {
        return getItemPrice() * getItemCount();
    }

    public int getInvoiceNumber() {
        return invoiceNumber;
    }

}
