/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Model;

import java.util.ArrayList;
import javax.swing.table.AbstractTableModel;

/**
 *
 * @author Abeer
 */
public class InvoiceLineTableModel extends AbstractTableModel {

    private String[] invoiceLinesColumns = {"Invoice No.", "Item name", "Item price", "Count", "Item total"};
    private ArrayList<InvoiceLine> invoiceLines;

    public InvoiceLineTableModel(ArrayList<InvoiceLine> invoiceLines) {
        this.invoiceLines = invoiceLines;
    }

    @Override
    public int getRowCount() {
        return invoiceLines.size();
    }

    @Override
    public int getColumnCount() {
        return invoiceLinesColumns.length;
    }

    @Override
    public String getColumnName(int columnIndex) {
        return invoiceLinesColumns[columnIndex];
    }

    @Override
    public Object getValueAt(int rowIndex, int columnIndex) {
        InvoiceLine invoiceLineContent = invoiceLines.get(rowIndex);
        switch (columnIndex) {
            case 0:
                return invoiceLineContent.getInvoiceNumber();
            case 1:
                return invoiceLineContent.getItemName();
            case 2:
                return invoiceLineContent.getItemPrice();
            case 3:
                return invoiceLineContent.getItemCount();
            case 4:
                return invoiceLineContent.getLineTotal();

        }
        return "";
    }

    public ArrayList<InvoiceLine> getInvoiceLines() {
        return invoiceLines;
    }

}
