/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JFrame.java to edit this template
 */
package View;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import javax.swing.JLabel;
import javax.swing.JTable;
import Controller.InvoiceListener;
import Model.InvoiceHeader;


/**
 *
 * @author Abeer
 */
public class InvoiceFrame extends javax.swing.JFrame {

    
    public InvoiceFrame() {
        initComponents();
    }

   
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        NewInvoiceHeaderjDialog = new javax.swing.JDialog();
        DialogCustomerNamejText = new javax.swing.JTextField();
        customerNameJLabel = new javax.swing.JLabel();
        invoiceDateJLabel = new javax.swing.JLabel();
        DialogInvoiceDatejText = new javax.swing.JTextField();
        addNewInvoiceHeader = new javax.swing.JButton();
        addNewInvoiceHeader.addActionListener(listner);
        cancelAddingInvoiceHeader = new javax.swing.JButton();
        cancelAddingInvoiceHeader.addActionListener(listner);
        NewInvoiceLineDialog = new javax.swing.JDialog();
        jLabel5 = new javax.swing.JLabel();
        jLabel6 = new javax.swing.JLabel();
        jLabel7 = new javax.swing.JLabel();
        addNewInvoiceLine = new javax.swing.JButton();
        addNewInvoiceLine.addActionListener(listner);
        cancelNewInvoiceLine = new javax.swing.JButton();
        cancelNewInvoiceLine.addActionListener(listner);
        DialogItemName = new javax.swing.JTextField();
        DialogItemPrice = new javax.swing.JTextField();
        DialogItemCount = new javax.swing.JTextField();
        jScrollPane1 = new javax.swing.JScrollPane();
        invoiceHeaderjTable = new javax.swing.JTable();
        invoiceHeaderjTable.getSelectionModel().addListSelectionListener(listner);
        jScrollPane2 = new javax.swing.JScrollPane();
        invoiceLinesjTable = new javax.swing.JTable();
        createNewInvoiceJButton = new javax.swing.JButton();
        createNewInvoiceJButton.addActionListener(listner);
        deleteInvoicejButton = new javax.swing.JButton();
        deleteInvoicejButton.addActionListener(listner);
        savejButton = new javax.swing.JButton();
        savejButton.addActionListener(listner);
        canceljButton = new javax.swing.JButton();
        canceljButton.addActionListener(listner);
        jLabel1 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        invoiceNumjLabel = new javax.swing.JLabel();
        customerNamejLabel = new javax.swing.JLabel();
        invoiceDatejLabel = new javax.swing.JLabel();
        invoiceTotaljLabel = new javax.swing.JLabel();
        jLabel9 = new javax.swing.JLabel();
        jLabel10 = new javax.swing.JLabel();
        jMenuBar1 = new javax.swing.JMenuBar();
        jMenu1 = new javax.swing.JMenu();
        loadMenuItem = new javax.swing.JMenuItem();
        loadMenuItem.addActionListener(listner);
        saveMenuItem = new javax.swing.JMenuItem();
        saveMenuItem.addActionListener(listner);

        NewInvoiceHeaderjDialog.setTitle("Add new invoice");
        NewInvoiceHeaderjDialog.setModal(true);

        customerNameJLabel.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        customerNameJLabel.setText("Customer name :");

        invoiceDateJLabel.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        invoiceDateJLabel.setText("Invoice Date :");

        addNewInvoiceHeader.setText("Add new invoice");
        addNewInvoiceHeader.setToolTipText("");

        cancelAddingInvoiceHeader.setText("Cancel");

        javax.swing.GroupLayout NewInvoiceHeaderjDialogLayout = new javax.swing.GroupLayout(NewInvoiceHeaderjDialog.getContentPane());
        NewInvoiceHeaderjDialog.getContentPane().setLayout(NewInvoiceHeaderjDialogLayout);
        NewInvoiceHeaderjDialogLayout.setHorizontalGroup(
            NewInvoiceHeaderjDialogLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(NewInvoiceHeaderjDialogLayout.createSequentialGroup()
                .addGap(33, 33, 33)
                .addGroup(NewInvoiceHeaderjDialogLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(NewInvoiceHeaderjDialogLayout.createSequentialGroup()
                        .addGroup(NewInvoiceHeaderjDialogLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addComponent(invoiceDateJLabel, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(customerNameJLabel, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                        .addGap(18, 18, 18)
                        .addGroup(NewInvoiceHeaderjDialogLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(DialogCustomerNamejText, javax.swing.GroupLayout.DEFAULT_SIZE, 204, Short.MAX_VALUE)
                            .addComponent(DialogInvoiceDatejText)))
                    .addGroup(NewInvoiceHeaderjDialogLayout.createSequentialGroup()
                        .addComponent(addNewInvoiceHeader)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(cancelAddingInvoiceHeader)))
                .addGap(24, 24, 24))
        );
        NewInvoiceHeaderjDialogLayout.setVerticalGroup(
            NewInvoiceHeaderjDialogLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(NewInvoiceHeaderjDialogLayout.createSequentialGroup()
                .addGap(27, 27, 27)
                .addGroup(NewInvoiceHeaderjDialogLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(customerNameJLabel)
                    .addComponent(DialogCustomerNamejText, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(NewInvoiceHeaderjDialogLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(invoiceDateJLabel)
                    .addComponent(DialogInvoiceDatejText, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(34, 34, 34)
                .addGroup(NewInvoiceHeaderjDialogLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(addNewInvoiceHeader)
                    .addComponent(cancelAddingInvoiceHeader))
                .addContainerGap(41, Short.MAX_VALUE))
        );

        NewInvoiceLineDialog.setTitle("Add new line");
        NewInvoiceLineDialog.setModal(true);
        NewInvoiceLineDialog.setName("Add_new_line"); // NOI18N

        jLabel5.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        jLabel5.setText("Item name : ");

        jLabel6.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        jLabel6.setText("Item price : ");

        jLabel7.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        jLabel7.setText("Item count :");

        addNewInvoiceLine.setText("Add new line");

        cancelNewInvoiceLine.setText("Cancel");
        cancelNewInvoiceLine.setActionCommand("CancelAddingLine");

        javax.swing.GroupLayout NewInvoiceLineDialogLayout = new javax.swing.GroupLayout(NewInvoiceLineDialog.getContentPane());
        NewInvoiceLineDialog.getContentPane().setLayout(NewInvoiceLineDialogLayout);
        NewInvoiceLineDialogLayout.setHorizontalGroup(
            NewInvoiceLineDialogLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(NewInvoiceLineDialogLayout.createSequentialGroup()
                .addGap(40, 40, 40)
                .addGroup(NewInvoiceLineDialogLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(NewInvoiceLineDialogLayout.createSequentialGroup()
                        .addGap(25, 25, 25)
                        .addComponent(addNewInvoiceLine)
                        .addGap(26, 26, 26)
                        .addComponent(cancelNewInvoiceLine)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 37, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(NewInvoiceLineDialogLayout.createSequentialGroup()
                        .addGroup(NewInvoiceLineDialogLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addComponent(jLabel5, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(jLabel6, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(jLabel7, javax.swing.GroupLayout.PREFERRED_SIZE, 72, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addGroup(NewInvoiceLineDialogLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(DialogItemPrice, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 139, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(DialogItemCount, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 139, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(DialogItemName, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 139, javax.swing.GroupLayout.PREFERRED_SIZE))))
                .addGap(56, 56, 56))
        );
        NewInvoiceLineDialogLayout.setVerticalGroup(
            NewInvoiceLineDialogLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(NewInvoiceLineDialogLayout.createSequentialGroup()
                .addGap(33, 33, 33)
                .addGroup(NewInvoiceLineDialogLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(DialogItemName, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel5, javax.swing.GroupLayout.Alignment.TRAILING))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(NewInvoiceLineDialogLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel6)
                    .addComponent(DialogItemPrice, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(9, 9, 9)
                .addGroup(NewInvoiceLineDialogLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel7)
                    .addComponent(DialogItemCount, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(41, 41, 41)
                .addGroup(NewInvoiceLineDialogLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(addNewInvoiceLine)
                    .addComponent(cancelNewInvoiceLine))
                .addContainerGap(18, Short.MAX_VALUE))
        );

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        invoiceHeaderjTable.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {

            }
        ));
        invoiceHeaderjTable.getTableHeader().setReorderingAllowed(false);
        jScrollPane1.setViewportView(invoiceHeaderjTable);

        invoiceLinesjTable.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {

            }
        ));
        jScrollPane2.setViewportView(invoiceLinesjTable);

        createNewInvoiceJButton.setText("Create new invoice");

        deleteInvoicejButton.setText("Delete invoice");

        savejButton.setText("New line");

        canceljButton.setText("Delete line");

        jLabel1.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        jLabel1.setText("Invoice number :");

        jLabel2.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        jLabel2.setText("Customer name :");

        jLabel3.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        jLabel3.setText("Invoice date :");

        jLabel4.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        jLabel4.setText("Invoide total :");

        invoiceNumjLabel.setText("-");

        customerNamejLabel.setText("-");

        invoiceDatejLabel.setText("-");

        invoiceTotaljLabel.setText("-");
        invoiceTotaljLabel.setToolTipText("");

        jLabel9.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        jLabel9.setText("Invoice items");

        jLabel10.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        jLabel10.setText("Invoices table");

        jMenu1.setText("File");

        loadMenuItem.setAccelerator(javax.swing.KeyStroke.getKeyStroke(java.awt.event.KeyEvent.VK_L, java.awt.event.InputEvent.CTRL_DOWN_MASK));
        loadMenuItem.setMnemonic('l');
        loadMenuItem.setText("Load Files");
        jMenu1.add(loadMenuItem);

        saveMenuItem.setAccelerator(javax.swing.KeyStroke.getKeyStroke(java.awt.event.KeyEvent.VK_S, java.awt.event.InputEvent.CTRL_DOWN_MASK));
        saveMenuItem.setMnemonic('s');
        saveMenuItem.setText("Save Files");
        jMenu1.add(saveMenuItem);

        jMenuBar1.add(jMenu1);

        setJMenuBar(jMenuBar1);

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(11, 11, 11)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 433, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel10, javax.swing.GroupLayout.PREFERRED_SIZE, 88, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addGap(72, 72, 72)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel1, javax.swing.GroupLayout.PREFERRED_SIZE, 103, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                                .addComponent(jLabel3, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                .addComponent(jLabel2, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                            .addComponent(jLabel4))
                        .addGap(35, 35, 35)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(invoiceNumjLabel, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(customerNamejLabel, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(invoiceDatejLabel, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(invoiceTotaljLabel, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)))
                    .addComponent(jLabel9, javax.swing.GroupLayout.PREFERRED_SIZE, 90, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(167, 167, 167))
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(savejButton)
                .addGap(200, 200, 200)
                .addComponent(canceljButton)
                .addGap(77, 77, 77))
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                .addGap(45, 45, 45)
                .addComponent(createNewInvoiceJButton)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 120, Short.MAX_VALUE)
                .addComponent(deleteInvoicejButton)
                .addGap(61, 61, 61)
                .addComponent(jScrollPane2, javax.swing.GroupLayout.PREFERRED_SIZE, 473, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(25, 25, 25))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(14, 14, 14)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addGroup(layout.createSequentialGroup()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel1)
                            .addComponent(invoiceNumjLabel))
                        .addGap(18, 18, 18)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel2)
                            .addComponent(customerNamejLabel))
                        .addGap(18, 18, 18)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel3)
                            .addComponent(invoiceDatejLabel))
                        .addGap(18, 18, 18)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel4)
                            .addComponent(invoiceTotaljLabel))
                        .addGap(33, 33, 33)
                        .addComponent(jLabel9))
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(jLabel10)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 159, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(jScrollPane2, javax.swing.GroupLayout.PREFERRED_SIZE, 167, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(layout.createSequentialGroup()
                        .addGap(91, 91, 91)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(createNewInvoiceJButton)
                            .addComponent(deleteInvoicejButton))))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 21, Short.MAX_VALUE)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(savejButton)
                    .addComponent(canceljButton))
                .addContainerGap(55, Short.MAX_VALUE))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        
        java.awt.EventQueue.invokeLater(new Runnable() {
            @Override
            public void run() {
                InvoiceFrame frame = new InvoiceFrame();
                frame.setVisible(true);
                frame.getListner().loadFiles("InvoiceHeader.csv", "InvoiceLine.csv");
                       
            }
        });
        
        
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JTextField DialogCustomerNamejText;
    private javax.swing.JTextField DialogInvoiceDatejText;
    private javax.swing.JTextField DialogItemCount;
    private javax.swing.JTextField DialogItemName;
    private javax.swing.JTextField DialogItemPrice;
    private javax.swing.JDialog NewInvoiceHeaderjDialog;
    private javax.swing.JDialog NewInvoiceLineDialog;
    private javax.swing.JButton addNewInvoiceHeader;
    private javax.swing.JButton addNewInvoiceLine;
    private javax.swing.JButton cancelAddingInvoiceHeader;
    private javax.swing.JButton cancelNewInvoiceLine;
    private javax.swing.JButton canceljButton;
    private javax.swing.JButton createNewInvoiceJButton;
    private javax.swing.JLabel customerNameJLabel;
    private javax.swing.JLabel customerNamejLabel;
    private javax.swing.JButton deleteInvoicejButton;
    private javax.swing.JLabel invoiceDateJLabel;
    private javax.swing.JLabel invoiceDatejLabel;
    private javax.swing.JTable invoiceHeaderjTable;
    private javax.swing.JTable invoiceLinesjTable;
    private javax.swing.JLabel invoiceNumjLabel;
    private javax.swing.JLabel invoiceTotaljLabel;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel10;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JMenu jMenu1;
    private javax.swing.JMenuBar jMenuBar1;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JMenuItem loadMenuItem;
    private javax.swing.JMenuItem saveMenuItem;
    private javax.swing.JButton savejButton;
    // End of variables declaration//GEN-END:variables

    private InvoiceListener listner = new InvoiceListener(this);
    public static  SimpleDateFormat simpleDateFormat = new SimpleDateFormat("dd-MM-yyyy");
    private ArrayList<InvoiceHeader>invoiceheaders;
    

    public JLabel getCustomerNamejLabel() {
        return customerNamejLabel;
    }

    public JLabel getInvoiceDatejLabel() {
        return invoiceDatejLabel;
    }

    public JLabel getInvoiceNumjLabel() {
        return invoiceNumjLabel;
    }

    public JLabel getInvoiceTotaljLabel() {
        return invoiceTotaljLabel;
    }

    public ArrayList<InvoiceHeader> getInvoiceheaders() {
        if (invoiceheaders == null)
            invoiceheaders=new ArrayList<>();
        return invoiceheaders;
    }



    public JTable getInvoiceHeaderjTable() {
        return invoiceHeaderjTable;
    }


    public javax.swing.JTable getInvoiceLinesjTable() {
        return invoiceLinesjTable;
    }


    public InvoiceListener getListner() {
        return listner;
    }

    public javax.swing.JTextField getDialogCustomerNamejText() {
        return DialogCustomerNamejText;
    }

    public javax.swing.JTextField getDialogInvoiceDatejText() {
        return DialogInvoiceDatejText;
    }

    public javax.swing.JDialog getjNewInvoiceHeaderjDialog() {

        return NewInvoiceHeaderjDialog;
    }

    public javax.swing.JTextField getDialogItemCount() {
        return DialogItemCount;
    }

    public javax.swing.JTextField getDialogItemName() {
        return DialogItemName;
    }

    public javax.swing.JTextField getDialogItemPrice() {
        return DialogItemPrice;
    }

    public javax.swing.JButton getAddNewInvoiceLine() {
        return addNewInvoiceLine;
    }

    public javax.swing.JButton getCancelNewInvoiceLine() {
        return cancelNewInvoiceLine;
    }

    public javax.swing.JDialog getNewInvoiceLineDialog() {
        return NewInvoiceLineDialog;
    }
    
 
    


}
